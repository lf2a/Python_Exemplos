# Para executar o código

> Todos os arquivos de teste devem começar com `test_`

Digite no terminal: `$ python -m unittest`

## Output

```bash
.....
----------------------------------------------------------------------
Ran 5 tests in 0.002s

OK
```